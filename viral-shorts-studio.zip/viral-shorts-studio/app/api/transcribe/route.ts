import { NextRequest,NextResponse } from "next/server";
import OpenAI from "openai";
import { createReadStream } from "node:fs";
import { writeFile } from "node:fs/promises";
import path from "node:path";
import { TMP,safeId } from "@/lib/server";
export const runtime="nodejs"; export const maxDuration=300;
const ai=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
export async function POST(req:NextRequest) {
 try {
  const {jobId:raw}=await req.json(); const id=safeId(raw);
  const audio=path.join(TMP,`${id}.mp3`);
  // Audio extraction is performed here with ffmpeg in a production worker; see README command.
  const {spawn}=await import("node:child_process");
  await new Promise<void>((resolve,reject)=>{const p=spawn(process.env.FFMPEG_PATH||"ffmpeg",["-y","-i",path.join(TMP,`${id}.mp4`),"-vn","-ac","1","-ar","16000","-b:a","64k",audio]);
   let err="";p.stderr.on("data",d=>err+=d.toString());p.on("error",reject);p.on("close",c=>c===0?resolve():reject(new Error(err.slice(-2000))));});
  const result=await ai.audio.transcriptions.create({file:createReadStream(audio),model:"whisper-1",response_format:"verbose_json",timestamp_granularities:["word","segment"]});
  await writeFile(path.join(TMP,`${id}.transcript.json`),JSON.stringify(result));
  return NextResponse.json({transcript:result,duration:result.duration});
 } catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Transcription failed"},{status:500});}
}