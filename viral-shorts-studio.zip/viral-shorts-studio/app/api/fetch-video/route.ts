import { NextRequest, NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import path from "node:path";
import { ensureTmp, TMP, bin, run, assertYoutubeUrl } from "@/lib/server";
export const runtime = "nodejs";
export const maxDuration = 300;
export async function POST(req:NextRequest) {
 try {
  const {url:raw}=await req.json(); const url=assertYoutubeUrl(raw);
  await ensureTmp(); const jobId=randomUUID(); const out=path.join(TMP,jobId);
  // Download best MP4 video+audio merged into one file. Restrict URL host before invoking yt-dlp.
  await run(bin("yt-dlp"),["--no-playlist","--no-warnings","-f","bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b",
   "--merge-output-format","mp4","-o",`${out}.%(ext)s`,url]);
  // yt-dlp's merged output path is deterministic with this template in typical installations.
  return NextResponse.json({jobId,videoPath:`${out}.mp4`});
 } catch(e) { return NextResponse.json({error:e instanceof Error?e.message:"Download failed"},{status:400}); }
}