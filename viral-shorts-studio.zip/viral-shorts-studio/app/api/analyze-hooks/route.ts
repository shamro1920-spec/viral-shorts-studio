import {NextRequest,NextResponse} from "next/server";
import OpenAI from "openai";
import {HOOK_SYSTEM_PROMPT} from "@/lib/hook-prompt";
export const runtime="nodejs";
const ai=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
const schema={type:"object",additionalProperties:false,properties:{hooks:{type:"array",items:{
 type:"object",additionalProperties:false,properties:{
  start_time:{type:"number"},end_time:{type:"number"},virality_score:{type:"integer",minimum:0,maximum:100},
  viral_title:{type:"string"},hook_text:{type:"string"}},
 required:["start_time","end_time","virality_score","viral_title","hook_text"]}}},required:["hooks"]};
export async function POST(req:NextRequest){
 try{
  const {transcript,duration}=await req.json();
  if(!transcript?.segments||!Array.isArray(transcript.segments)) throw new Error("Timestamped transcript segments are required");
  const response=await ai.chat.completions.create({model:"gpt-4o",temperature:0.2,
   messages:[{role:"system",content:HOOK_SYSTEM_PROMPT},{role:"user",content:JSON.stringify({duration,segments:transcript.segments})}],
   response_format:{type:"json_schema",json_schema:{name:"viral_hooks",strict:true,schema}}});
  const parsed=JSON.parse(response.choices[0].message.content||'{"hooks":[]}');
  const hooks=parsed.hooks.filter((h:any)=>h.start_time>=0&&h.end_time>h.start_time&&h.end_time-h.start_time<=75&&(!duration||h.end_time<=duration+1));
  return NextResponse.json({hooks});
 }catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Hook analysis failed"},{status:500});}
}