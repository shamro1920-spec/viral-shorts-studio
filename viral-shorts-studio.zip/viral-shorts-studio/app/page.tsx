 "use client";
import { useState } from "react";
type Hook = {start_time:number;end_time:number;virality_score:number;viral_title:string;hook_text:string};
export default function Home() {
 const [url,setUrl]=useState(""); const [job,setJob]=useState(""); const [hooks,setHooks]=useState<Hook[]>([]);
 const [busy,setBusy]=useState(false); const [status,setStatus]=useState("");
 async function post(endpoint:string,body:unknown) {
  const r=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
  const data=await r.json(); if(!r.ok) throw new Error(data.error||"Request failed"); return data;
 }
 async function analyze() {
  setBusy(true); setStatus("Downloading video and extracting audio…"); setHooks([]);
  try {
   const fetched=await post("/api/fetch-video",{url}); setJob(fetched.jobId);
   setStatus("Transcribing audio…"); const transcript=await post("/api/transcribe",{jobId:fetched.jobId});
   setStatus("Finding the strongest moments…"); const result=await post("/api/analyze-hooks",{transcript:transcript.transcript, duration:transcript.duration});
   setHooks(result.hooks); setStatus("Select a moment to render.");
  } catch(e) { setStatus(e instanceof Error?e.message:"Something went wrong"); }
  finally { setBusy(false); }
 }
 async function render(h:Hook) {
  setBusy(true); setStatus(`Rendering: ${h.viral_title}`);
  try { const out=await post("/api/render-clip",{jobId:job,start_time:h.start_time,end_time:h.end_time});
   setStatus(`Rendered: ${out.file}`); }
  catch(e){setStatus(e instanceof Error?e.message:"Render failed");}
  finally{setBusy(false);}
 }
 return <main className="mx-auto max-w-4xl px-6 py-16">
  <div className="mb-10"><p className="text-sm font-semibold tracking-widest text-violet-400">AI VIDEO EDITOR</p>
   <h1 className="mt-3 text-4xl font-bold">Viral Shorts Studio</h1>
   <p className="mt-3 text-zinc-400">Turn long-form YouTube videos into captioned vertical clips.</p></div>
  <section className="rounded-2xl border border-zinc-800 bg-zinc-900 p-6">
   <label className="mb-2 block text-sm text-zinc-300">YouTube video URL</label>
   <input value={url} onChange={e=>setUrl(e.target.value)} placeholder="https://www.youtube.com/watch?v=…"
    className="w-full rounded-lg border border-zinc-700 bg-zinc-950 px-4 py-3 outline-none focus:border-violet-500"/>
   <button disabled={busy||!url} onClick={analyze} className="mt-4 rounded-lg bg-violet-600 px-5 py-3 font-semibold disabled:opacity-40">
    {busy?"Working…":"Find viral moments"}
   </button>
   {status&&<p className="mt-4 text-sm text-zinc-300">{status}</p>}
  </section>
  <section className="mt-8 space-y-4">{hooks.map((h,i)=><article key={i} className="rounded-xl border border-zinc-800 bg-zinc-900 p-5">
   <div className="flex items-start justify-between gap-4"><h2 className="font-semibold">{h.viral_title}</h2>
    <span className="rounded-full bg-violet-950 px-3 py-1 text-sm text-violet-300">{h.virality_score}/100</span></div>
   <p className="mt-3 text-sm leading-6 text-zinc-300">{h.hook_text}</p>
   <p className="mt-3 text-xs text-zinc-500">{h.start_time.toFixed(1)}s – {h.end_time.toFixed(1)}s</p>
   <button disabled={busy} onClick={()=>render(h)} className="mt-4 rounded-lg border border-zinc-700 px-4 py-2 text-sm hover:bg-zinc-800 disabled:opacity-40">Render 9:16 clip</button>
  </article>)}</section>
  <p className="mt-12 text-xs leading-5 text-zinc-600">Use only videos you own or have permission to process. This starter writes rendered clips to the server's tmp directory; add authenticated downloads and durable storage before public deployment.</p>
 </main>;
}