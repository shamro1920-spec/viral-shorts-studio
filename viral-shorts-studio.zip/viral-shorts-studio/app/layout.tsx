import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = { title:"Viral Shorts Studio", description:"Find and render the best moments from your videos." };
export default function RootLayout({children}:{children:React.ReactNode}) {
 return <html lang="en"><body>{children}</body></html>;
}