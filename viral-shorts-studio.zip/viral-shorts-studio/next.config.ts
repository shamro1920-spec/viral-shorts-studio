import type { NextConfig } from "next";
const config: NextConfig = { serverExternalPackages: ["openai"] };
export default config;